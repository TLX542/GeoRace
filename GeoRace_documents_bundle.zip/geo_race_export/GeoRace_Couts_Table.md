# Chiffrage MVP (6 mois)

## Humains: 215.5k EUR
## Infra: 57k EUR
## Autres: 30k EUR

**Total: ~302.5k EUR**
