# Personas GeoRace

## Persona 1 — Emma, 29 ans
- Coureuse régulière (4x/semaine)
- Objectif : motivation, compétition équitable
- Besoins : duels 1v1, ELO, badges

## Persona 2 — Lucas, 35 ans
- Coureur occasionnel (1-2x/semaine)
- Objectif : fun, social
- Besoins : interface simple, 3 duels/jour gratuit

## Persona 3 — Amina, 24 ans
- Coureuse compétitive
- Objectif : tester sa forme
- Besoins : stats avancées, anti-triche robuste
