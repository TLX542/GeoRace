# Wireframes

## Home

![Home](assets/wireframe_home.svg)

## Duel Modal

![Duel](assets/wireframe_duel_modal.svg)

## Live Race

![Live](assets/wireframe_live.svg)

## Résultat

![Result](assets/wireframe_result.svg)
