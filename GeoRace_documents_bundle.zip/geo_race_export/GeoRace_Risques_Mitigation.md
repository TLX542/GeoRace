# Matrice risques

| Risque | Prob | Impact | Mitigation |
|---|:---:|:---:|---|
| Fuite position | M | H | Chiffrement |
| Triche | H | H | Anti-cheat |
| Densité faible | H | M | Ghost-runners |
| Rejet Store | M | H | Flow onboarding |
