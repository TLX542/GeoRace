# Étude hébergement

## Cloud managed (recommandé)
- AWS/GCP
- Déploiement rapide

## Self-host
- CAPEX moindre
- Time-to-market lent

**Choix: Cloud managed**
