# PBS — Périmètre fonctionnel

## MVP (Phase 1)
- Mobile cross-platform
- Détection coureurs (500m-2km)
- Point d'arrivée équidistant (1v1)
- Départ synchronisé
- Tracking GPS temps réel
- ELO basique
- Anti-cheat basique
- Tests 2-3 villes
