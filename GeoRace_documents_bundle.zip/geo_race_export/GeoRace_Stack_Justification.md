# Stack technique

## Mobile
- React Native (TypeScript)

## Backend
- Node.js/Go
- WebSocket
- Kafka/Redis Streams
- Postgres + PostGIS

## Ops
- Kubernetes
- Prometheus/Grafana
- GitHub Actions
