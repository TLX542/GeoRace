# Contexte & Sécurité

## Marché
- Strava, NRC : asynchrones
- Zwift : virtuel
- Carto : Mapbox, OSM

## Règles légales
- RGPD : consentement, chiffrement
- Background GPS : justification stricte
- Responsabilité : T&C, assurance

## Risques
- Fuite position
- Triche GPS
- DDoS gateway
