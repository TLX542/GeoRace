# Éco-score

## Empreinte MVP
- 300-800 kg CO2e/an

## Optimisations
- Adaptive GPS
- Compression
- Cloud green

**Cible: <500 kg CO2e/an**
