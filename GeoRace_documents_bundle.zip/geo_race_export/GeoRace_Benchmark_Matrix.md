# Benchmark concurrents

| App | Duels réel | Point équidistant | ELO | 1v1 local |
|---|:---:|:---:|:---:|:---:|
| Strava | Non | Non | Non | Non |
| Nike Run Club | Non | Non | Non | Non |
| Zwift Run | Virtuel | Non | Non | Non |
| **GeoRace** | **Oui** | **Oui** | **Oui** | **Oui** |
