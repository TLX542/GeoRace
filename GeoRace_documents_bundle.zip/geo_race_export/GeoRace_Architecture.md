# Architecture MVP

![Architecture](assets/architecture.png)

- WebSocket pour positions haute fréquence
- PostGIS pour géospatial
- Kubernetes auto-scaling
